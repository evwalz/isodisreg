# Isotonic distributional regression (IDR)

Code is adapted from https://github.com/AlexanderHenzi/isodistrreg

Information on IDR can be found here: https://arxiv.org/abs/1909.03725.
